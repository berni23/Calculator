var numsHTMLCollection = document.getElementsByClassName("button-number");
var symHTMLCollection = document.getElementsByClassName("button-symbol");
var equalSym = document.querySelector(".equal");
var screen = document.querySelector(".operations");
var dot = document.querySelector(".button-dot");
var plusMin = document.querySelector(".button-plusMinus");

//var numPi = document.querySelector(".button-pi");
//numPi.addEventListener("click", addPi);

var operation;
var num1;
var num2;
var numTyped = 0;
var deciTyped = 0;
var symTyped;
var decimal = false;
var operationsList = "";

dot.addEventListener("click", addNumberString);
dot.addEventListener("click", decimalBool);
plusMin.addEventListener("click", plusMin);
for (let i = 0; i < numsHTMLCollection.length; i++) {
    numsHTMLCollection[i].addEventListener("click", addNumberString);
}

for (let i = 0; i < symHTMLCollection.length; i++) {
    symHTMLCollection[i].addEventListener("click", addNumberString);
    symHTMLCollection[i].addEventListener("click", currentOperation);
}
//function addPi(event){
//    numTyped =
//}
function addNumberString(event) {

    let targetButton = event.currentTarget;
    let txt;
    // if the character is a number, concatenate it and add it to numTyped

    if (Array.from(numsHTMLCollection).includes(targetButton)) {
        txt = targetButton.innerHTML;

        if (decimal) {
            deciTyped = Number("" + deciTyped + txt);
            numTyped = float(numTyped, deciTyped);
        }
        else {
            numTyped = Number("" + numTyped + txt);
        }
    } else {
        txt = targetButton.firstElementChild.innerHTML;
        symTyped = txt;
    }

    screen.innerHTML += txt;
}
function clearScreen() {
    screen.innerHTML = "";
    resetVars();
}
function currentOperation(event) {
    decimal = false;
    if (num1 == undefined) {
        num1 = numTyped;
    } else {
        num2 = numTyped;
    }

    numTyped = 0;
    if (operation != undefined) {
        performOperation();
        screen.innerHTML = num1 + symTyped;
    }
    operation = event.currentTarget.id;
}

function performOperation() {
    let result;
    switch (operation) {
        case "plus":
            result = sum(num1, num2);
            break;
        case "minus":
            result = diff(num1, num2);
            break;
        case "multiply":
            result = mult(num1, num2);
            break;
        case "divide":
            result = div(num1, num2);
            break;
        case "perc":
            result = perc(num1, num2);
            break;
    }
    console.log(num1, operation, num2, "=",result);
    num1 = round(result, 10);

    //num1 = result.toFixed(2);
}
/* Operations */
function sum(a, b) {
    return a + b;
}
function mult(a, b) {
    return a * b;
}
function diff(a, b) {
    return a - b;
}
function div(a, b) {
    return a / b;
}
function perc(a, b) {
    return a / 100 * b;
}
function float(a, b) {
    let numLength = b.toString().length;
    return a + (b / (10 ** (numLength)));
}
function round(value, decimals) {
    return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals);
}
function decimalBool() {
    decimal = true;
}
function plusMinus() {
    numTyped = numTyped * (-1);
}
function equal() {
    if (operation != undefined && num1 != undefined) {
        num2 = numTyped;
        performOperation();
        screen.innerHTML = num1;
        operation = undefined;
    }
    decimal = false;
}
function resetVars() {
    num1 = undefined;
    num2 = undefined;
    operation = undefined;
    operationsList = "";
    numTyped = 0;
    deciTyped = 0;
    decimal = false;
}
// TOOGLE LAYOUT
function toggleLayout() {
    let screenBckgDark = document.querySelector(".screenWrapper");
    screenBckgDark.classList.toggle("screenWrapper-dark");

    let buttonsBckgDark = document.querySelector(".buttons");
    buttonsBckgDark.classList.toggle("buttons-dark");

    for (let i = 0; i < symHTMLCollection.length; i++) {
        symHTMLCollection[i].classList.toggle("btn-sym-dark");
    }

    for (let j = 0; j < numsHTMLCollection.length; j++) {
        numsHTMLCollection[j].classList.toggle("btn-num-dark");
    }

    let buttonClearDark = document.querySelector(".button-clear");
    buttonClearDark.classList.toggle("btn-clear-dark");

    let buttonDotDark = document.querySelector(".button-dot");
    buttonDotDark.classList.toggle("btn-dot-dark");

    let sliderDark = document.querySelector(".slider");
    sliderDark.classList.toggle("slider-dark");

    let buttonPlusMinDark = document.querySelector(".button-plusMinus");
    buttonPlusMinDark.classList.toggle("btn-plusMinus-dark");

    let buttonPiDark = document.querySelector(".button-pi");
    buttonPiDark.classList.toggle("btn-pi-dark");
}